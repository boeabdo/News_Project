<?php

namespace App\Providers;

use App\Models\Post;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\ServiceProvider;

class CashServiceProvider extends ServiceProvider
{
    /**
     * Register services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap services.
     */
    public function boot(): void
    {
        if (!Cache::has('posts_read_more')) {
            $posts_read_more = Post::select('id', 'title')->latest()->limit(10)->get();
//            Cache::forever('posts_read_more', $posts_read_more);
            Cache::remember('posts_read_more', 3600, function () use ($posts_read_more) {
                return $posts_read_more;
            });
        }
        $posts_read_more = Cache::get('posts_read_more');
        view()->share([
            'posts_read_more' => $posts_read_more
        ]);

    }
}
