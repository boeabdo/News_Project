<?php

namespace App\Providers;

use App\Models\RelatedNewsSite;
use App\Models\Setting;
use Illuminate\Support\ServiceProvider;

class CheckSettingProvider extends ServiceProvider
{
    /**
     * Register services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap services.
     */
    public function boot(): void
    {
        $getSettings = Setting::firstOr(function (){
            $date=fake()->date(format: 'Y-m-d h:m:s');
            return Setting::create(
                [
                    'site_name' => 'News',
                    'email' => 'email22@gamil.com',
                    'favicon' => 'favicon',
                    'logo' => '/img/logo.png',
                    'facebook' => 'https://www.facebook.com',
                    'twitter' => 'https://www.twitter.com',
                    'instagram' => 'https://www.instagram.com',
                    'youtube' => 'https://www.youtube.com',
                    'phone' => '+201091523688',
                    'country' => 'Egypt',
                    'city' => 'Mansoura',
                    'street' => 'street',
                    'created_at' => $date,
                    'updated_at' => $date,
                ]
            );
        });

        // Retrieve all related news sites
        $relatedSites = RelatedNewsSite::all();

        // Share settings and related sites with all views
        view()->share([
            'getSettings' => $getSettings,
            'relatedSites' => $relatedSites,
        ]);
    }
}
