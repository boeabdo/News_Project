<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Post;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    public function index()
    {
        $posts = Post::with('images')->latest()->paginate(9);
        $greatest_posts_views = Post::with('images')
            ->orderBy('num_of_views','desc')
            ->limit(3)
            ->get();

        $greatest_posts_comments = Post::withCount('comments')
            ->orderBy('comments_count','desc')
            ->take(3)
            ->get();

        $categories = Category::all();
        $category_with_posts = $categories->map(function($category){
            $category->posts = $category->posts()->limit(2)->get();
            return $category;
        });
//        return $category_with_posts;
        return view('frontend.index',compact(
            'posts',
            'greatest_posts_views',
            'greatest_posts_comments',
            'category_with_posts'
        ));
    }
}
